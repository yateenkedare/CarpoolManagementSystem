# CarpoolManagementSystem


Simple Hello Name program for Sprint 0
Takes in Name of the user and inserts it into the database.
Reads last entered name from the database and displays it.
