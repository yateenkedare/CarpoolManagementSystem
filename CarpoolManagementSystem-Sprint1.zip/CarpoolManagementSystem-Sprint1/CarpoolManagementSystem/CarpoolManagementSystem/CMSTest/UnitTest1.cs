﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CarpoolManagementSystem;
namespace CMSTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod] 
        public void TestMethod1()
        {

        }
    }
}
