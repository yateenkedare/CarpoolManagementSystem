CREATE SCHEMA `test` ;
CREATE TABLE `test`.`test` (
  `Name` VARCHAR(45) NOT NULL,
  `Number` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Number`));
